import sys


class ModuleE:
    def exitProgram(self):
        print("Program Exit !")
        sys.exit()
