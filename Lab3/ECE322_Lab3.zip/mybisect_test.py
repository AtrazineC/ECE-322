import unittest
from mybisect import Polynomial
from mybisect import MyBisect


class TestMyBisect(unittest.TestCase):
    def test_normal(self):
        # Normal test case
        f = Polynomial(1, 1)  # x + 1
        b = MyBisect(f)
        result = b.run(-10, 10)
        self.assertAlmostEqual(0, f(result), None,
                               None, b.tolerance)

    def test_both_positive(self):
        # f(x1) > 0 and f(x2) > 0
        f = Polynomial(1, 0, 1)  # x^2 + 1
        b = MyBisect(f)
        self.assertRaises(ValueError, b.run, -10, 10)

    def test_exceed_max_iteration(self):
        # Test max iterations exceeded
        # This takes more than 50 iterations
        f = Polynomial(1, 0)  # x
        b = MyBisect(f)
        self.assertRaises(ValueError, b.run,
                          -1, 100000000000)

    def test_default_constructor(self):
        # Test default constructor (no args)
        b = MyBisect()
        self.assertRaises(TypeError, b.run, -10, 10)

    def test_tolerance_constructor(self):
        # Test tolerance constructor (tol = 10.0)
        f = Polynomial(1, 0)  # x
        b = MyBisect(10.0, f)
        result = b.run(-10, 10)
        self.assertEqual(0, result)

    def test_max_it_constructor(self):
        # Test max iterator constructor (max it = 100)
        # Increasing the max iteration acc should
        # allow us to find the result unlike
        # test_exceed_max_iteration() which reaches
        # the max iteration count.
        # This should take 51 iterations
        f = Polynomial(1, 0)  # x
        b = MyBisect(100, f)
        result = b.run(-1, 100000000000)
        self.assertAlmostEqual(0, f(result), None,
                               None, b.tolerance)

    def test_tolerance_and_max_it_constructor(self):
        # Test tolerance and max iterator constructor
        # (tol = 10.0, max it = 100)
        f = Polynomial(1, 0)  # x
        b = MyBisect(10.0, 100, f)
        result = b.run(-1, 1)
        self.assertAlmostEqual(0, f(result), None,
                               None, b.tolerance)

    def test_tolerance_getter(self):
        # Test tolerance getter
        f = Polynomial(1, 0)  # x
        b = MyBisect(f)
        self.assertEqual(0.000001, b.tolerance)

    def test_tolerance_setter(self):
        # Test tolerance setter
        f = Polynomial(1, 0)  # x
        b = MyBisect(f)
        b.tolerance = 10.0
        self.assertEqual(10.0, b.tolerance)

    def test_max_iterations_getter(self):
        # Test max iterations getter
        f = Polynomial(1, 0)  # x
        b = MyBisect(f)
        self.assertEqual(50, b.maxIterations)

    def test_max_iterations_setter(self):
        # Test max iterations setter
        f = Polynomial(1, 0)  # x
        b = MyBisect(f)
        b.maxIterations = 5
        self.assertEqual(5, b.maxIterations)


if __name__ == "__main__":
    unittest.main()
